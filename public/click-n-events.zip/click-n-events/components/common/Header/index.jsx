"use Client"
import React, {useState} from 'react'
import locationmenu from "@/assets/images/icons/locationmenu.png";
import pin from "@/assets/images/icons/pin.png";
import loginicon from "@/assets/images/icons/loginicon.png";
import supporticon from "@/assets/images/icons/supporticon.png";
import languagemenu from "@/assets/images/icons/languagemenu.png";
import polygon from "@/assets/images/icons/Polygon.svg";
import { Navigation } from '@/components/Navigation';


function Header({showTopHeader}) {
    const [selectedOption, setSelectedOption] = useState("Delhi");
     const [selectLanguage, setSelectLanguage] = useState("English");

      const handleChange = (e) => {
    setSelectedOption(e.target.value);
  };
  const handleLanguageChange = (e) => {
    setSelectLanguage(e.target.value);
  };

  return (
     <div className="fixed_header">
     {
        showTopHeader &&(
            <div className="top_nav_wrapper">
          <div className="location">
            <img 
              src={pin.src}
              className="locationpin"
              alt="location menu preview"
            
            />
            <select
              value={selectedOption}
              onChange={handleChange}
              className="custom-dropdown"
            >
              <option value="Delhi">Delhi</option>
              <option value="Mumbai">Mumbai</option>
              <option value="Chennai">Chennai</option>
              <option value="Kolkata">Kolkata</option>
            </select>
            {/* <div className="dropdown-rectangle">
    </div> */}
            {/* <Image className="polygon" src={polygon} alt="polygon" /> */}
          </div>
          <div className="signupandsupport">
            <div className="loginsupportbox">
              <ul>
                <li>
                  <img
                    src={loginicon.src}
                    className="locationpin"
                    alt="login signup preview"
                  />
                  Login / Signup
                </li>
                <li>
                  <img 
                    src={supporticon.src}
                    className="locationpin"
                    alt="customer support preview"
                  />
                  Customer Support
                </li>
              </ul>
            </div>
            <div className="language-dropdown">
              <select
                value={selectLanguage}
                onChange={setSelectedOption}
                className="custom-dropdown2"
              >
                <option value="Delhi">Hindi</option>
                <option value="Mumbai">English</option>
                <option value="Chennai">Tamil</option>
                <option value="Kolkata">Bangla</option>
              </select>
            </div>
          </div>
        </div>
        )
     }
        <Navigation />
        </div>
  )
}

export default Header
